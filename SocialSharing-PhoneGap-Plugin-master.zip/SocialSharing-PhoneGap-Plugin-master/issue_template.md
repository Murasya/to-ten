This is a free plugin for which I'm no longer able to offer free support.

If you want me to look at your issue with priority (or at all) you may want to consider giving my PayPal account a bit of love. Details are in the readme.

Thank you,
Eddy
